//
//  ViewController.m
//  翻页
//
//  Created by ios1 on 2017/10/10.
//  Copyright © 2017年 ios1. All rights reserved.
//

#import "ViewController.h"
#import "ZYFlipViewController.h"
#import "ZYDetailViewController.h"
@interface ViewController ()
@property(nonatomic, strong)ZYFlipViewController *flipViewController;
@property(nonatomic, strong)NSMutableArray *viewControllers;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.view addSubview:self.flipViewController.view];
    // Do any additional setup after loading the view, typically from a nib.
}

- (ZYFlipViewController *)flipViewController {
    if (_flipViewController == nil) {
        _flipViewController = [[ZYFlipViewController alloc]init];
        _flipViewController.viewControllers = self.viewControllers;
    }
    return _flipViewController;
}

- (NSMutableArray*)viewControllers{
    if (_viewControllers == nil) {
        ZYDetailViewController * vc1= [ZYDetailViewController new];
        vc1.numStr = @"1";
        ZYDetailViewController * vc2= [ZYDetailViewController new];
          vc2.numStr = @"2";
        ZYDetailViewController * vc3= [ZYDetailViewController new];
          vc3.numStr = @"3";
        ZYDetailViewController * vc4= [ZYDetailViewController new];
          vc4.numStr = @"4";
        ZYDetailViewController * vc5= [ZYDetailViewController new];
          vc5.numStr = @"5";
        ZYDetailViewController * vc6= [ZYDetailViewController new];
          vc6.numStr = @"6";
        _viewControllers = [NSMutableArray arrayWithObjects:vc1,vc2,vc3,vc4,vc5,vc6, nil];
    }
    return _viewControllers;
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
