//
//  main.m
//  FlieBoard
//
//  Created by ios1 on 2017/10/21.
//  Copyright © 2017年 ios1. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
